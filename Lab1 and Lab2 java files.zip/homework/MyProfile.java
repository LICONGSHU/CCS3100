package test;

public class MyProfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************************************************");
		System.out.println("*                                                                                 *");
		System.out.println("*                                 LI CONGSHU Profile                              *");
		System.out.println("***********************************************************************************");
		
		System.out.println("Name:LI CONGSHU");
		System.out.println("Matric:BC254555");
		System.out.println("state Province:China Sichuan");
		System.out.println("Is this program your first choice?: Yes");
		System.out.println("Expectaions form this cource:I expect i can learning this courese is well");
		
		
		

	}

}
