package test;

public class DisplayaPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("    J");
		System.out.println("J  aaa   v   vaaa");
		System.out.println("J  J  aa  v v   a a");
		System.out.println("J   aaaa   v    aaaa");
		

	}

}
