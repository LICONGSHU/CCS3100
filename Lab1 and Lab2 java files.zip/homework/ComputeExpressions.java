package test;

public class ComputeExpressions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a =7.5;
		double b =6.5;
		double c =4.5;
		double d =3;
		double e =47.5;
		double f =5.5;
		System.out.println("(a*b-c*d)/(e-f)" + ((a*b-c*d)/(e-f)));

	}

}
