package Main;

public class Weight {
	public static void main (String[] args) {
		double A = 500;
		double B = 0.001;
		double C = 2.20462;
		System.out.println("KG= A * B = " + A * B);
		System.out.println("Pounds= A * B * C= "+A * B * C);
		
	}

}
