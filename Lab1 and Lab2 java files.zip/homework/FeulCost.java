package Main;

public class FeulCost {
	public static void main(String[] args) {
		double A = 350;
		double B = 100;
		double C = 6.5;
		double D = 2.1;
		
		System.out.println("Feul Cost = A / B * C * D = " + (A / B * C * D ));
		
	}

}
