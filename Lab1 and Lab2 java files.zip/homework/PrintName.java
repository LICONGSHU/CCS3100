package test;

public class PrintName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Name = "LI CONGSHU";
		System.out.println(Name);

	}

}
