package test;

public class ILoveJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String content = "I Love Java";
		for(int i = 0;i<5;i++) {
			System.out.println(content);
		}

	}

}
